# NetflixHomepage
It is a Netflix Home page using HTML and CSS .
